package e_wallet;

public class Vendor {
	public int id;
	public String name;
	public String uname;
	public String password;
	public double ewbalance;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public double getEwbalance() {
		return ewbalance;
	}
	public void setEwbalance(double ewbalance) {
		this.ewbalance = ewbalance;
	}
	
}
